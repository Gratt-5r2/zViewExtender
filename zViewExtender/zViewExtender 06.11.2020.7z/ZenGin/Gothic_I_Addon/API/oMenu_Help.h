// Supported with union (c) 2018 Union team

#ifndef __OMENU__HELP_H__VER1__
#define __OMENU__HELP_H__VER1__

namespace Gothic_I_Addon {

} // namespace Gothic_I_Addon

#endif // __OMENU__HELP_H__VER1__