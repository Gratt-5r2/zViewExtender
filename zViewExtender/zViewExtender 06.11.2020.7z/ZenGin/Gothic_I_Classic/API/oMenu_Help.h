// Supported with union (c) 2018 Union team

#ifndef __OMENU__HELP_H__VER0__
#define __OMENU__HELP_H__VER0__

namespace Gothic_I_Classic {

} // namespace Gothic_I_Classic

#endif // __OMENU__HELP_H__VER0__