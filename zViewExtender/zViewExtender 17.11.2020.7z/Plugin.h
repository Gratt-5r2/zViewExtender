
// This file added in headers queue
// File: "Headers.h"

namespace NAMESPACE {
#define MOUSE_KEY_LEFT_G1  2050
#define MOUSE_KEY_MID_G1   2051
#define MOUSE_KEY_RIGHT_G1 2052
#define MOUSE_WHEELUP_G1   2057
#define MOUSE_WHEELDOWN_G1 2058
}