// Supported with union (c) 2018 Union team
// Add your sources this

#pragma region Includes
#include "zTexAniHandler/zTexAniHandler.cpp"
#include "zViewAnimated/zViewAnimated.cpp"
#include "zViewCursor/zViewCursor.cpp"
#include "zViewInteractive/zViewInteractive.cpp"
#include "zRenderProcess/zRenderProcess.cpp"
#include "zView/zView.cpp"
#include "zView/zMenuHandler.cpp"
#include "zView/zInventoryHandler.cpp"
#include "zViewShaped\zViewShaped.cpp"
#include "zView/zDialogHandler.cpp"
#include "Plugin.cpp"
#pragma endregion

// ...