// Supported with union (c) 2018 Union team

#ifndef __ZLOCAL_H__VER2__
#define __ZLOCAL_H__VER2__

namespace Gothic_II_Classic {

} // namespace Gothic_II_Classic

#endif // __ZLOCAL_H__VER2__